from flask import Flask, render_template, request, json
from flaskext.mysql import MySQL
import os
import Modelo as Modelo

app = Flask(__name__)

@app.route("/Log")
def Ingresar():
 return render_template("login.html")
 
@app.route("/Inicio")
def Inicio():
 return render_template("index.html")
 
@app.route('/Registro',methods=['POST','GET'])
def re():
        try:
            _N = request.form.get('Name')
            _L = request.form.get('LastName')
            _E = request.form.get('Email')
            _P = request.form.get('Password')
            if _N and _L and _E and _P:
                return Modelo.InsertName(_N, _L, _E, _P)
            else:
                return json.dumps({'html':'<span>Datos Incompletos</span>'})
        except Exception as e:
            print(str(e))
            return json.dumps({'error':str(e)})
        finally:
                return render_template('Registro.html') 
 
 
 
if __name__ == "__main__":
 app.run()